// 
// 
// 

#include "HomeSecurity.h"

void HomeSecurityClass::init()
{


}


HomeSecurityClass HomeSecurity;

